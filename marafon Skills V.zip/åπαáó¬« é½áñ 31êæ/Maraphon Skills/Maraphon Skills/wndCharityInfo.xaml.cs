﻿using Maraphon_Skills;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;


namespace Maraphon_Skills_Zhuravko
{
    /// <summary>
    /// Логика взаимодействия для wndCharityInfo.xaml
    /// </summary>
    public partial class wndCharityInfo : Window
    {
        public wndCharityInfo(Charity charity)
        {
            InitializeComponent();

            label_charityName.Content = charity.CharityName;
            textBlock.Text = charity.CharityDescription;

            image.Source = new BitmapImage(new Uri(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "charities", charity.CharityLogo)));
        }
    }
}

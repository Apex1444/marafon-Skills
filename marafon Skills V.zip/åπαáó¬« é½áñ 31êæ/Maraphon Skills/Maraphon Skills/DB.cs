﻿using Maraphon_Skills;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maraphon_Skills_Zhuravko
{
    public static class Util
    {
        private static MarathonSkillsEntities2 database;
            public static MarathonSkillsEntities2 db
        {
            get
            {
                if (database == null)
                    database = new MarathonSkillsEntities2();
                return database; 

            }
        }
    }
}
